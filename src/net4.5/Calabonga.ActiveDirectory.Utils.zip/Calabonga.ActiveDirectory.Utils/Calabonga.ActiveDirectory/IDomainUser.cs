﻿namespace Calabonga.ActiveDirectory {

    /// <summary>
    /// Domain user abstractions for Principal
    /// </summary>
    public interface IDomainUser {
        string Name { get; set; }
        
        string Description { get; set; }
        
        string SamAccountName { get; set; }

        string DisplayName { get; set; }

        string DistinguishedName { get; set; }
        
        string UserPrincipalName { get; set; }
    }

    public class DomainUser : IDomainUser
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public string SamAccountName { get; set; }
        public string DisplayName { get; set; }
        public string DistinguishedName { get; set; }
        public string UserPrincipalName { get; set; }
    }
}
