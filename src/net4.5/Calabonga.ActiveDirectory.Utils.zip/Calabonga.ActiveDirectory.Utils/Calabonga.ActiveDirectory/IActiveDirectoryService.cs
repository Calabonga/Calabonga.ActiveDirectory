using System.Collections.Generic;

namespace Calabonga.ActiveDirectory
{
    /// <summary>
    /// Active Directory helper
    /// </summary>
    public interface IActiveDirectoryService {
        /// <summary>
        /// Returns user display name from Active Directory
        /// </summary>
        /// <param name="domainName">domain name</param>
        /// <param name="accountName">user account name</param>
        /// <returns></returns>
        string GetUserDisplayName(string domainName, string accountName);

        /// <summary>
        /// Returns user email from Active Directory
        /// </summary>
        /// <param name="domainName">domain name</param>
        /// <param name="accountName">user account name</param>
        /// <returns></returns>
        string GetUserEmail(string domainName, string accountName);

        IEnumerable<string> GetDepartments(string domainName);

        /// <summary>
        /// Get avaliable domain list
        /// </summary>
        /// <returns></returns>
        IEnumerable<string> GetDomains();

        IEnumerable<string> OrganizationUnits(string domainName);

        /// <summary>
        /// Get users from selected groups
        /// </summary>
        /// <param name="domain"></param>
        /// <param name="groups"></param>
        /// <returns></returns>
        List<string> GetUsersDisplayNameInGroups(string domain, params string[] groups);

        /// <summary>
        /// Returns a list of users object from groups of domain
        /// </summary>
        /// <param name="domain">domain name</param>
        /// <param name="groups">groups name as string params</param>
        /// <returns></returns>
        List<IDomainUser> GetUsersInGroups(string domain, params string[] groups);

        /// <summary>
        /// Returns groups under ASP.NET HttpContext
        /// </summary>
        /// <returns></returns>
        IEnumerable<string> GetCurrentUserGroups();

        IEnumerable<string> GetUserGroupsMemberOf(string userName, bool recursive);

        /// <summary>
        /// Returns object distinguished name
        /// </summary>
        /// <param name="objectCls"></param>
        /// <param name="returnValue"></param>
        /// <param name="objectName"></param>
        /// <param name="ldapDomain"></param>
        /// <returns></returns>
        string GetObjectDistinguishedName(ObjectClass objectCls, ReturnType returnValue, string objectName,
            string ldapDomain);

        /// <summary>
        /// Returns groups
        /// </summary>
        /// <param name="userDn"></param>
        /// <param name="recursive"></param>
        /// <returns></returns>
        IEnumerable<string> Groups(string userDn, bool recursive);

        string GetDepartment(string username);

        string GetCurrentUserName { get; }
    }
}