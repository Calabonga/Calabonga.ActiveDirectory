namespace Calabonga.ActiveDirectory
{
    public enum ObjectClass {
        User, Group, Computer
    }
}