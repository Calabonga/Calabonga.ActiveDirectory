using System;
using System.Collections.Generic;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;
using System.DirectoryServices.ActiveDirectory;
using System.Linq;
using System.Security.Principal;
using System.Web;

namespace Calabonga.ActiveDirectory {
    public class ActiveDirectoryService : IActiveDirectoryService {

        public string GetCurrentUserName {
            get {
                try {
                    return UserPrincipal.Current.SamAccountName;
                }
                catch (PrincipalServerDownException exception) {
                    return Environment.UserName;
                }
            }

        }

        public string GetObjectDistinguishedName(ObjectClass objectCls, ReturnType returnValue, string objectName, string ldapDomain) {
            if (objectName == null) return "\"objectName\" is NULL";
            if (ldapDomain == null) return "\"ldapDomain\" is NULL";
            var distinguishedName = string.Empty;
            var connectionPrefix = "LDAP://" + ldapDomain;

            try {
                using (var entry = new DirectoryEntry(connectionPrefix)) {
                    using (var mySearcher = new DirectorySearcher(entry)) {
                        switch (objectCls) {
                            case ObjectClass.User:
                                mySearcher.Filter = "(&(objectClass=user)(|(cn=" + objectName + ")(sAMAccountName=" + objectName + ")))";
                                break;
                            case ObjectClass.Group:
                                mySearcher.Filter = "(&(objectClass=group)(|(cn=" + objectName + ")(dn=" + objectName + ")))";
                                break;
                            case ObjectClass.Computer:
                                mySearcher.Filter = "(&(objectClass=computer)(|(cn=" + objectName + ")(dn=" + objectName + ")))";
                                break;
                        }
                        var result = mySearcher.FindOne();

                        if (result == null) {
                            throw new NullReferenceException("unable to locate the distinguishedName for the object " + objectName + " in the " + ldapDomain + " domain");
                        }
                        using (var directoryObject = result.GetDirectoryEntry()) {

                            if (returnValue.Equals(ReturnType.DistinguishedName)) {
                                distinguishedName = "LDAP://" + directoryObject.Properties["distinguishedName"].Value;
                            }
                            if (returnValue.Equals(ReturnType.ObjectGuid)) {
                                distinguishedName = directoryObject.Guid.ToString();
                            }
                        }
                        entry.Close();
                        entry.Dispose();
                        mySearcher.Dispose();
                        return distinguishedName;
                    }
                }
            }
            catch (Exception exception) {
                return exception.Message;
            }
        }

        public IEnumerable<string> GetDepartments(string domainName) {
            using (var myLdapConnection = new DirectoryEntry(string.Concat("LDAP://", domainName))) {
                using (var search = new DirectorySearcher(myLdapConnection)) {

                    search.Filter = "(objectClass=user)";
                    search.PropertiesToLoad.Add("department");
                    var result = search.FindAll();
                    var departments = new List<string>();
                    foreach (SearchResult depart in result) {
                        using (var directoryEntry = depart.GetDirectoryEntry()) {
                            if (directoryEntry.Properties.Contains("department")
                                && depart.Properties["department"] != null
                                && depart.Properties["department"].Count > 0) {
                                var dept = (string)depart.Properties["department"][0];
                                departments.Add(dept);
                            }
                        }
                    }
                    return departments;
                }
            }
        }

        /// <summary>
        /// Returns user display name from Active Directory
        /// </summary>
        /// <param name="domainName">domain name</param>
        /// <param name="accountName">user account name</param>
        /// <returns></returns>
        public string GetUserDisplayName(string domainName, string accountName) {
            try {
                using (var entry = new DirectoryEntry("LDAP://" + domainName)) {
                    entry.AuthenticationType = AuthenticationTypes.Secure;
                    using (var searcher = new DirectorySearcher(entry)) {
                        searcher.SearchScope = SearchScope.Subtree;
                        searcher.Filter = "(&(objectClass=user)(samaccountname=" + accountName + "))";
                        searcher.PropertiesToLoad.AddRange(new[] { "displayname", "samaccountname" });
                        var result = searcher.FindOne();
                        return (result != null
                            && result.Properties["DisplayName"] != null
                            && result.Properties["DisplayName"].Count > 0)
                            ? result.Properties["DisplayName"][0].ToString()
                            : null;
                    }
                }
            }
            catch (ActiveDirectoryOperationException exception) {
                return exception.Message;
            }
        }

        /// <summary>
        /// Returns user email from Active Directory
        /// </summary>
        /// <param name="domainName">domain name</param>
        /// <param name="accountName">user account name</param>
        /// <returns></returns>
        public string GetUserEmail(string domainName, string accountName) {
            try {
                using (var entry = new DirectoryEntry("LDAP://" + domainName)) {
                    entry.AuthenticationType = AuthenticationTypes.Secure;
                    using (var searcher = new DirectorySearcher(entry)) {
                        searcher.SearchScope = SearchScope.Subtree;
                        searcher.PropertiesToLoad.Clear();
                        searcher.Filter = "(&(objectClass=user)(samaccountname=" + accountName + "))";
                        searcher.PropertiesToLoad.Add("mail");
                        var result = searcher.FindOne();
                        return (result != null
                            && result.Properties["mail"] != null
                            && result.Properties["mail"].Count > 0)
                            ? result.Properties["mail"][0].ToString() : null;
                    }
                }
            }
            catch (ActiveDirectoryOperationException exception) {
                return exception.Message;
            }
        }
        public IEnumerable<string> Groups(string userDn, bool recursive) {
            var groupMemberships = new List<string>();
            return AttributeValuesMultiString("memberOf", userDn,
                groupMemberships, recursive);
        }

        /// <summary>
        /// Get a list of the avaliable domains
        /// </summary>
        /// <returns></returns>
        public IEnumerable<string> GetDomains() {
            var list = new List<string>();
            try {
                var currentForest = Forest.GetCurrentForest();
                var myDomains = currentForest.Domains;
                list.AddRange(from Domain objDomain in myDomains select objDomain.Name);
            }
            catch {
                // ignored
            }
            return list;
        }

        public IEnumerable<string> OrganizationUnits(string domainName) {
            var alObjects = new List<string>();
            try {
                using (var directoryObject = new DirectoryEntry("LDAP://" + domainName)) {

                    foreach (DirectoryEntry child in directoryObject.Children) {
                        var childPath = child.Path;
                        alObjects.Add(childPath.Remove(0, 7));
                        child.Close();
                        child.Dispose();
                    }
                    directoryObject.Close();
                }
            }
            catch {
                // ignored
            }

            return alObjects;
        }

        /// <summary>
        /// Get users from selected groups
        /// </summary>
        /// <param name="domain"></param>
        /// <param name="groups"></param>
        /// <returns></returns>
        public List<string> GetUsersDisplayNameInGroups(string domain, params string[] groups) {
            var result = new List<string>();
            if (groups == null) return result;
            foreach (var group in groups) {
                try {
                    using (var ctx = new PrincipalContext(ContextType.Domain, domain)) {
                        using (var grp = GroupPrincipal.FindByIdentity(ctx, IdentityType.SamAccountName, group)) {
                            if (grp == null) continue;
                            result.AddRange(grp.GetMembers(false).Select(p => p.DisplayName));
                        }
                    }
                }
                catch (Exception) {
                    // ignored
                }
            }
            var ret = result.Distinct();
            return ret.ToList();
        }

        /// <summary>
        /// Returns a list of users object from groups of domain
        /// </summary>
        /// <param name="domain">domain name</param>
        /// <param name="groups">groups name as string params</param>
        /// <returns></returns>
        public List<IDomainUser> GetUsersInGroups(string domain, params string[] groups) {
            var result = new List<IDomainUser>();
            if (groups == null) return result;
            foreach (var group in groups) {
                try {
                    using (var ctx = new PrincipalContext(ContextType.Domain, domain)) {
                        using (var grp = GroupPrincipal.FindByIdentity(ctx, IdentityType.SamAccountName, group)) {
                            if (grp == null) continue;
                            result.AddRange(grp.GetMembers(false).Select(p => new DomainUser {
                                DisplayName = p.DisplayName,
                                Description = p.Description,
                                Name = p.Name,
                                DistinguishedName = p.DistinguishedName,
                                SamAccountName = p.SamAccountName,
                                UserPrincipalName = p.UserPrincipalName
                            }));
                        }
                    }
                }
                catch (Exception) {
                    // ignored
                }
            }
            return result;
        }


        /// <summary>
        /// Returns groups under ASP.NET HttpContext
        /// </summary>
        /// <returns></returns>
        public IEnumerable<string> GetCurrentUserGroups() {
            var groups = new List<string>();
            if (HttpContext.Current.Request.LogonUserIdentity == null) return groups;
            if (HttpContext.Current.Request.LogonUserIdentity.Groups == null) return groups;
            groups.AddRange(HttpContext.Current.Request.LogonUserIdentity.Groups.Select(@group => @group.Translate(typeof(NTAccount)).ToString()));
            return groups;
        }

        public IEnumerable<string> GetUserGroupsMemberOf(string userName, bool recursive) {
            var groupMemberships = new List<string>();
            return AttributeValuesMultiString("MemberOf", userName, groupMemberships, recursive);
        }

        public IEnumerable<string> AttributeValuesMultiString(string attributeName, string objectDn, IList<string> valuesCollection, bool recursive) {
            using (var ent = new DirectoryEntry(objectDn)) {

                var valueCollection = ent.Properties[attributeName];
                if (valueCollection == null) return null;
                var enumerator = valueCollection.GetEnumerator();

                while (enumerator.MoveNext()) {
                    if (enumerator.Current != null) {
                        if (!valuesCollection.Contains(enumerator.Current.ToString())) {
                            valuesCollection.Add(enumerator.Current.ToString());
                            if (recursive) {
                                AttributeValuesMultiString(attributeName, "LDAP://" + enumerator.Current, valuesCollection, true);
                            }
                        }
                    }
                }
                return valuesCollection;
            }
        }

        public string GetDepartment(string username) {
            var result = string.Empty;
            try {
                var yourDomain = new PrincipalContext(ContextType.Domain);
                var user = UserPrincipal.FindByIdentity(yourDomain, username);
                if (user == null) return result;
                var directoryEntry = (user.GetUnderlyingObject() as DirectoryEntry);
                if (directoryEntry == null) return result;
                if (directoryEntry.Properties.Contains("department")
                    && directoryEntry.Properties["department"] != null
                    && directoryEntry.Properties["department"].Count > 0) {
                    result = directoryEntry.Properties["department"][0].ToString();
                }
            }
            catch (Exception) {
                //ignore
            }

            return result;
        }
    }
}