﻿using System;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;

namespace Calabonga.ActiveDirectory
{
    public static class AccountManagementExtensions {

        public static String GetProperty(this Principal principal, String property) {
            DirectoryEntry directoryEntry = principal.GetUnderlyingObject() as DirectoryEntry;
            if (directoryEntry != null && directoryEntry.Properties.Contains(property))
                return directoryEntry.Properties[property].Value.ToString();
            return String.Empty;
        }

        public static String GetCompany(this Principal principal) {
            return GetProperty(principal, "company");
        }

        public static String GetDepartment(this Principal principal) {
            return GetProperty(principal, "department");
        }

    }
}