namespace Calabonga.ActiveDirectory
{
    public enum ReturnType {
        DistinguishedName, ObjectGuid
    }
}