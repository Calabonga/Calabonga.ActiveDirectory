﻿namespace Calabonga.ActiveDirectory.Demo {
    partial class FormMain {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMain));
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.listBoxDomains = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.listBoxDepartments = new System.Windows.Forms.ListBox();
            this.label4 = new System.Windows.Forms.Label();
            this.listBoxGroups = new System.Windows.Forms.ListBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.checkBoxRecursive = new System.Windows.Forms.CheckBox();
            this.buttonGetUserInGroup = new System.Windows.Forms.Button();
            this.listBoxUsersInGroup = new System.Windows.Forms.ListBox();
            this.textBoxGroupName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.listBoxUsersInGroups = new System.Windows.Forms.ListBox();
            this.button2 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxgroupsNames = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.labelUserName = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.labelDisplayName = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.labelEmail = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.Location = new System.Drawing.Point(609, 443);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "Close";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Domains";
            // 
            // listBoxDomains
            // 
            this.listBoxDomains.FormattingEnabled = true;
            this.listBoxDomains.Location = new System.Drawing.Point(12, 29);
            this.listBoxDomains.Name = "listBoxDomains";
            this.listBoxDomains.Size = new System.Drawing.Size(120, 186);
            this.listBoxDomains.TabIndex = 3;
            this.listBoxDomains.SelectedValueChanged += new System.EventHandler(this.listBoxDomains_SelectedValueChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(135, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Departments";
            // 
            // listBoxDepartments
            // 
            this.listBoxDepartments.FormattingEnabled = true;
            this.listBoxDepartments.Location = new System.Drawing.Point(138, 29);
            this.listBoxDepartments.Name = "listBoxDepartments";
            this.listBoxDepartments.Size = new System.Drawing.Size(120, 186);
            this.listBoxDepartments.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(261, 12);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "Groups";
            // 
            // listBoxGroups
            // 
            this.listBoxGroups.FormattingEnabled = true;
            this.listBoxGroups.Location = new System.Drawing.Point(264, 29);
            this.listBoxGroups.Name = "listBoxGroups";
            this.listBoxGroups.Size = new System.Drawing.Size(120, 186);
            this.listBoxGroups.TabIndex = 12;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.panel1.Controls.Add(this.checkBoxRecursive);
            this.panel1.Controls.Add(this.buttonGetUserInGroup);
            this.panel1.Controls.Add(this.listBoxUsersInGroup);
            this.panel1.Controls.Add(this.textBoxGroupName);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Location = new System.Drawing.Point(12, 221);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(316, 216);
            this.panel1.TabIndex = 13;
            // 
            // checkBoxRecursive
            // 
            this.checkBoxRecursive.AutoSize = true;
            this.checkBoxRecursive.Checked = true;
            this.checkBoxRecursive.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxRecursive.Location = new System.Drawing.Point(14, 53);
            this.checkBoxRecursive.Name = "checkBoxRecursive";
            this.checkBoxRecursive.Size = new System.Drawing.Size(69, 17);
            this.checkBoxRecursive.TabIndex = 15;
            this.checkBoxRecursive.Text = "recursive";
            this.checkBoxRecursive.UseVisualStyleBackColor = true;
            // 
            // buttonGetUserInGroup
            // 
            this.buttonGetUserInGroup.Location = new System.Drawing.Point(225, 25);
            this.buttonGetUserInGroup.Name = "buttonGetUserInGroup";
            this.buttonGetUserInGroup.Size = new System.Drawing.Size(79, 23);
            this.buttonGetUserInGroup.TabIndex = 14;
            this.buttonGetUserInGroup.Text = "User in group";
            this.buttonGetUserInGroup.UseVisualStyleBackColor = true;
            this.buttonGetUserInGroup.Click += new System.EventHandler(this.buttonGetUserInGroup_Click);
            // 
            // listBoxUsersInGroup
            // 
            this.listBoxUsersInGroup.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listBoxUsersInGroup.FormattingEnabled = true;
            this.listBoxUsersInGroup.Location = new System.Drawing.Point(14, 78);
            this.listBoxUsersInGroup.Name = "listBoxUsersInGroup";
            this.listBoxUsersInGroup.Size = new System.Drawing.Size(290, 121);
            this.listBoxUsersInGroup.TabIndex = 13;
            // 
            // textBoxGroupName
            // 
            this.textBoxGroupName.Location = new System.Drawing.Point(14, 25);
            this.textBoxGroupName.Name = "textBoxGroupName";
            this.textBoxGroupName.Size = new System.Drawing.Size(205, 20);
            this.textBoxGroupName.TabIndex = 12;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(11, 8);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "Enter group name:";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.listBoxUsersInGroups);
            this.panel2.Controls.Add(this.button2);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.textBoxgroupsNames);
            this.panel2.Location = new System.Drawing.Point(335, 221);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(349, 216);
            this.panel2.TabIndex = 14;
            // 
            // listBoxUsersInGroups
            // 
            this.listBoxUsersInGroups.FormattingEnabled = true;
            this.listBoxUsersInGroups.Location = new System.Drawing.Point(15, 52);
            this.listBoxUsersInGroups.Name = "listBoxUsersInGroups";
            this.listBoxUsersInGroups.Size = new System.Drawing.Size(322, 147);
            this.listBoxUsersInGroups.TabIndex = 16;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(262, 25);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 15;
            this.button2.Text = "Users in";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 8);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(195, 13);
            this.label5.TabIndex = 14;
            this.label5.Text = "Enter group names (adminis, users, etc):";
            // 
            // textBoxgroupsNames
            // 
            this.textBoxgroupsNames.Location = new System.Drawing.Point(15, 25);
            this.textBoxgroupsNames.Name = "textBoxgroupsNames";
            this.textBoxgroupsNames.Size = new System.Drawing.Size(240, 20);
            this.textBoxgroupsNames.TabIndex = 13;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.labelEmail);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.labelDisplayName);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.labelUserName);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Location = new System.Drawing.Point(391, 29);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(293, 186);
            this.panel3.TabIndex = 15;
            // 
            // labelUserName
            // 
            this.labelUserName.AutoSize = true;
            this.labelUserName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelUserName.Location = new System.Drawing.Point(80, 4);
            this.labelUserName.Name = "labelUserName";
            this.labelUserName.Size = new System.Drawing.Size(14, 13);
            this.labelUserName.TabIndex = 1;
            this.labelUserName.Text = "_";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(4, 4);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(69, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "Current User:";
            // 
            // labelDisplayName
            // 
            this.labelDisplayName.AutoSize = true;
            this.labelDisplayName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelDisplayName.Location = new System.Drawing.Point(80, 28);
            this.labelDisplayName.Name = "labelDisplayName";
            this.labelDisplayName.Size = new System.Drawing.Size(14, 13);
            this.labelDisplayName.TabIndex = 3;
            this.labelDisplayName.Text = "_";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(4, 28);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(72, 13);
            this.label8.TabIndex = 2;
            this.label8.Text = "DisplayName:";
            // 
            // labelEmail
            // 
            this.labelEmail.AutoSize = true;
            this.labelEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelEmail.Location = new System.Drawing.Point(80, 52);
            this.labelEmail.Name = "labelEmail";
            this.labelEmail.Size = new System.Drawing.Size(14, 13);
            this.labelEmail.TabIndex = 5;
            this.labelEmail.Text = "_";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(4, 52);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(60, 13);
            this.label10.TabIndex = 4;
            this.label10.Text = "User Email:";
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(699, 476);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.listBoxGroups);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.listBoxDepartments);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.listBoxDomains);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormMain";
            this.Text = "Demo Calabonga.ActiveDirectory";
            this.Load += new System.EventHandler(this.FormMain_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox listBoxDomains;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListBox listBoxDepartments;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ListBox listBoxGroups;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.CheckBox checkBoxRecursive;
        private System.Windows.Forms.Button buttonGetUserInGroup;
        private System.Windows.Forms.ListBox listBoxUsersInGroup;
        private System.Windows.Forms.TextBox textBoxGroupName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBoxgroupsNames;
        private System.Windows.Forms.ListBox listBoxUsersInGroups;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label labelUserName;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label labelEmail;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label labelDisplayName;
        private System.Windows.Forms.Label label8;
    }
}

