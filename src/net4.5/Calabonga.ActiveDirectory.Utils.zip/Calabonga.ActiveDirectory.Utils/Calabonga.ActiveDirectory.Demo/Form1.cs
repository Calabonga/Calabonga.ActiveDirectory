﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace Calabonga.ActiveDirectory.Demo {
    public partial class FormMain : Form {

        private readonly IActiveDirectoryService _activeDirectory;

        public FormMain() {
            InitializeComponent();
            _activeDirectory = new ActiveDirectoryService();
        }

        private void button1_Click(object sender, EventArgs e) {
            Application.Exit();
        }

        private void FormMain_Load(object sender, EventArgs e) {
            listBoxDomains.DataSource = _activeDirectory.GetDomains();
            labelUserName.Text = _activeDirectory.GetCurrentUserName;
            var domain = listBoxDomains.SelectedValue.ToString();
            if (!string.IsNullOrWhiteSpace(domain)) {
                labelDisplayName.Text = _activeDirectory.GetUserDisplayName(domain, _activeDirectory.GetCurrentUserName);
                labelEmail.Text = _activeDirectory.GetUserEmail(domain, _activeDirectory.GetCurrentUserName);
            }
        }

        private void listBoxDomains_SelectedValueChanged(object sender, EventArgs e) {
            var domain = ((ListBox)sender).SelectedValue.ToString();
            listBoxDepartments.DataSource = _activeDirectory.GetDepartments(domain);
        }

        private void buttonGetUserInGroup_Click(object sender, EventArgs e) {
            if (!string.IsNullOrWhiteSpace(textBoxGroupName.Text)) {
                listBoxUsersInGroup.DataSource = _activeDirectory.GetUserGroupsMemberOf(textBoxGroupName.Text, checkBoxRecursive.Checked);
            }
        }

        private void button2_Click(object sender, EventArgs e) {
            if (string.IsNullOrWhiteSpace(textBoxgroupsNames.Text)) return;
            var groups = textBoxgroupsNames.Text.Split(',', ';', '|');
            var domain = _activeDirectory.GetDomains().First();
            var users = _activeDirectory.GetUsersDisplayNameInGroups(domain, groups);
            listBoxUsersInGroups.DataSource = users;
        }


    }
}
